
import React from 'react'
import { useSearchParams } from 'react-router-dom'
import {

  Box,
  
} from '@chakra-ui/react'

function App2() {
  const [searchParams, setSearchParams] = useSearchParams();
  console.warn(searchParams.get('age'))
  console.warn(searchParams.get('city'))
  // h1
  const age = searchParams.get('age');
  const city = searchParams.get('city')
  return (
    <>
<Box style={{ padding: "12px" ,background:"black",color: "white" }}>
  <button onClick={() => setSearchParams({ age: 19, city: 2004 })} colorScheme='blue'>Click me</button>
</Box>


      <h6>{city}</h6>
      <h6>{age}</h6>

    </>
    
  )
}

export default App2

