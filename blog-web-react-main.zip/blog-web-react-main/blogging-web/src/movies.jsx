import React from 'react'

function movies(props) {
  return (
      <div>
      <img src={props.year} alt="" />
      </div>
  )
}

export default movies