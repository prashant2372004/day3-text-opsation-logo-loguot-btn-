import React from 'react';


const GoodMorning = () => {
  let curDate = new Date(   ); // Get current date and time
  let hour = curDate.getHours(); // Get current hour
  let greeting = '';
  let cssStyle = {};

  if (hour >= 1 && hour < 12) {
    greeting = 'Good Morning';
    cssStyle.color = 'green';
  } else if (hour >= 12 && hour < 19) {
    greeting = 'Good Afternoon';
    cssStyle.color = 'orange';
  } else {
    greeting = 'Good Night';
    cssStyle.color = 'black';
  }

  return (
    <div>
      <h1>
        Hello Sir,
        <span style={cssStyle}>{greeting}</span>
      </h1>
    </div>
  );
};

export default GoodMorning;
