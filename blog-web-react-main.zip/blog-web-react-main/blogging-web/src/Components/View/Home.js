import React from 'react'
import { useNavigate } from 'react-router-dom'

const Home = () => {
  const navigate =useNavigate()
  const goto =() =>{
    navigate ('/Blog')
  }
  return (
    <div>
      <button onClick={goto}>Blog</button>
      
      {/* <button onClick={()=>{navigator(-1)}}>go bke</button>     not work */}
      <button onClick={() => { window.history.back() }}>go back</button>

    </div>
  )
}                                                                                                                                                                                                                                           

export default Home
