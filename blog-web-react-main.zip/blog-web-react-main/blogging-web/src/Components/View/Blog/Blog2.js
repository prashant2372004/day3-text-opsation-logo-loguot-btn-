import React, { useState } from 'react';
import { Box,SimpleGrid } from "@chakra-ui/react"
function Blog2() {
  const [text, setText] = useState('');
  const handleTextChange = (e) => {
    setText(e.target.value);
  };
  
  const handleUpperChange = () => {
    let newtext = text.toUpperCase()
    setText(newtext);
  };
  const handleUpperChange2 = () => {
    let newtext = text.toLocaleLowerCase()
    setText(newtext);
  };
  const handleUpperChange3 = () => {
    let newtext =''
    setText(newtext);
  };
  const handleUpperChange4 = () => {
    let newtext = text.split(/[ ]+/)
    setText(newtext.join());
  };
  const handleUpperChange5 = () => {
    let newtext = document.getElementById("mybox");
    newtext.select();
    navigator.clipboard.writeText(newtext.value);
  };


  const wordCount = text.trim().split(/\s+/).length;
  
  return (
    <div className="Blog2">
      <h1>Word Counter</h1>  <SimpleGrid
  bg='gray.50'
  columns={{ sm: 2, md: 4 }}
  spacing='8'
  p='10'
  textAlign='center'
  rounded='lg'
  color='gray.400'
><Box boxShadow='dark-lg' p='6' rounded='md' bg='blackAlpha.50'>
      <textarea onChange={handleTextChange} value={text} id="mybox"  ></textarea>

  </Box>
  <Box boxShadow='dark-lg' p='6' rounded='md' bg='blackAlpha.50'>
      <button onClick={handleUpperChange}>toUpperCase</button>

  </Box>
  <Box boxShadow='dark-lg' p='6' rounded='md' bg='blackAlpha.50'>
      <button onClick={handleUpperChange2}>toLocaleLowerCase</button>

  </Box>
  <Box boxShadow='dark-lg' p='6' rounded='md' bg='blackAlpha.50'>
      <button onClick={handleUpperChange3}>CLEAR </button>

  </Box>
  <Box boxShadow='dark-lg' p='6' rounded='md' bg='blackAlpha.50'>

      <button onClick={handleUpperChange4}>join </button>
  </Box>
  <Box boxShadow='dark-lg' p='6' rounded='md' bg='blackAlpha.50'>

      <button onClick={handleUpperChange5}>copy</button>
</Box>
 <Box boxShadow='dark-lg' p='6' rounded='md' bg='blackAlpha.50'>
      <p>Word count: {wordCount}</p>

</Box>
  
</SimpleGrid>
  
    </div>
  );
}

export default Blog2;

