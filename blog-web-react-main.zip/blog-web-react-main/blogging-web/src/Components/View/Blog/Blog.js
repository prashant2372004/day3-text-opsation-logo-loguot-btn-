import React from 'react'

import { useNavigate } from 'react-router-dom'
import { Box } from "@chakra-ui/react"

const Blog = () => {
  var uuid = require('uuid-v4');
 
  // navigate
  const navigate =useNavigate()
  const bkehoe=()=>{
    navigate('/Home')
  }
 


  return (
    // uuid id
    <><h1> {uuid()}</h1>

     {/* navigate */}
     <Box boxShadow='dark-lg' p='' rounded='md' bg='blackAlpha.50'>


    <button onClick={bkehoe} colorScheme='teal' size='lg' >home</button>
</Box>


    </>
  )


}
export default Blog









