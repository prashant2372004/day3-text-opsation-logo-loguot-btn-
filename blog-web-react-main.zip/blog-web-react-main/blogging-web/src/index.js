import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App';
// fill
import App2 from './App2';
import Mathadafach from './mathadafache';

import Movies from './movies';
import Sdmoies from './moies.json';

import { BrowserRouter } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';

// toastify
import 'react-toastify/dist/ReactToastify.css';
import { ToastContainer } from 'react-toastify';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <BrowserRouter>
  <ToastContainer/>
    <App />
    <App2/>
    {/* {Sdmoies.map((element) => {
  return <Movies year={element.Poster} />
})}
       */}
      
      
      {/* year set props */}




    
    <Mathadafach/>
  </BrowserRouter>
);

