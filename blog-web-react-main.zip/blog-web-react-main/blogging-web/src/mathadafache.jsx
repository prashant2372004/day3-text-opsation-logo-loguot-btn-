
import { useEffect, useState } from 'react';

function App() {
  // const [data, setData] = useState([]);
  // useEffect(() => {
  //   const url = "https://jsonplaceholder.typicode.com/comments";
  //   fetch(url)
  //     .then(response => response.json()) // corrected method name
  //     .then(json => {
  //       console.log("jsonnnn", json);
  //       setData(json);
  //     })
  //     .catch(e => {
  //       console.log("e", e);
  //     });
  // }, []);

  // return (
  //   <div className="App">
    
  //     {data.map(item => { // corrected curly brace
  //       return (
  //         <div>{item.email}</div> 
  //         // corrected closing tag
  //       );
  //     })}
  //   </div>
  // );
}

export default App;
